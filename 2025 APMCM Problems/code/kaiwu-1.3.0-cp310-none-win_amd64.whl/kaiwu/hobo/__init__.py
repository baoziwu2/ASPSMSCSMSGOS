# -*- coding: utf-8 -*-
"""
模块: hobo

功能: hobo建模工具
"""

from kaiwu.hobo._hobo_model import HoboModel

__all__ = [
    "HoboModel"
]
